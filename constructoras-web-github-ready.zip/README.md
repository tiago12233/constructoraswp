# Constructoras Web

Sitio web generado a partir del proyecto original.

## Publicar con GitHub Pages

1. Sube todo el contenido de este repositorio a GitHub.
2. En GitHub entra a **Settings → Pages**.
3. En **Build and deployment**, selecciona **Deploy from a branch**.
4. Selecciona la rama `main` y la carpeta `/ (root)`.
5. Guarda los cambios.

GitHub Pages publicará `index.html` como página principal.
